class EmployeeTest {
    public static void main(String[] args) {
        Employee emp1 = new Employee("John", "Doe", 5000.0);
        Employee emp2 = new Employee("Jane", "Smith", -2000.0);
          System.out.println("Employee 1:");
        System.out.println("Full Name: " + emp1.getFirstName() + " " + emp1.getLastName());
        System.out.println("Yearly Salary: " + emp1.getYearlySalary());
        System.out.println("\nEmployee 2:");
        System.out.println("Full Name: " + emp2.getFirstName() + " " + emp2.getLastName());
        System.out.println("Yearly Salary: " + emp2.getYearlySalary());
        
        emp1.raiseSalary(10);
        emp2.raiseSalary(10);
        
        System.out.println("\nAfter 10% raise:");
        System.out.println("Employee 1 Yearly Salary: " + emp1.getYearlySalary());
        System.out.println("Employee 2 Yearly Salary: " + emp2.getYearlySalary());
    }
}