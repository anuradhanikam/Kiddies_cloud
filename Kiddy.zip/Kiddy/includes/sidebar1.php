<nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
           
            
            <li class="nav-item">
              <a class="nav-link" href="">
              <i class=""></i>
                <span class="menu-title"></span>

              </a>
            </li>
            
            <li class="nav-item">
              <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
                <i class=""></i>
                <span class="menu-title"></span>
              </a>
              <li class="nav-item">
              <a class="nav-link" href="dashboard1.php">
              <i class="icon-home menu-icon"></i>
                <span class="menu-title">Dashboard</span>

              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="parent.php">
                <i class="icon-magnifier menu-icon"></i>
                <span class="menu-title">Search</span>
              </a>
            </li>
              
            </li>
          </ul>
        </nav>